<?php

$config['googlecontact']['application_name'] = 'Contacts';
$config['googlecontact']['client_id'] = '531642364953-8mkn0du24uftl7l3gp4kjhks2mquv46b.apps.googleusercontent.com';
$config['googlecontact']['client_secret'] = '_ju7_iSjEIFtWt62Isky6yq8';
$config['googlecontact']['redirect_uri'] = 'https://www.wish-fish.com/app/import/contacts';
$config['googlecontact']['api_key'] = 'AIzaSyDlhC9ZCWLDiIx6p7dqaYzcDpuHDOsJ03w';

