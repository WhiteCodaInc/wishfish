<?php

$config['googleplus']['application_name'] = 'Wish-Fish';
$config['googleplus']['client_id'] = '531642364953-e7cjuc4gc11c3mbdpapgk4n2lgam1ohl.apps.googleusercontent.com';
$config['googleplus']['client_secret'] = 'et9Rh5gsB2NeKxI9ozt6Vm0d';
$config['googleplus']['redirect_uri'] = 'https://www.wish-fish.com/register/signup';
$config['googleplus']['api_key'] = 'AIzaSyDlhC9ZCWLDiIx6p7dqaYzcDpuHDOsJ03w';

