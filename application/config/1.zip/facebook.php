<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

$config['appID'] = '788794537880865';
$config['appSecret'] = 'c93b6034618ab97c74a44585210e982e';
